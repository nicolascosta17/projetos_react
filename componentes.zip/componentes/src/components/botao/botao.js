import'./botao.css' // Importado a estilização do botao.css

function Primeiro_Botao(){ // Função que cria um botão, por enquanto sem ação
    return( 
        <button>Eu sou um botão</button> // Retorna o botão com a mensagem "Eu sou um botão"
    );
}

export default Primeiro_Botao // Exporta função Primeito_Botao