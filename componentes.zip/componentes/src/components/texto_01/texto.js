let valor; // Declarada a variável valor
let user; // Decalrada a variável user
valor = "Testando"; // Atribuido o valor string para a variável "valor"
function Texto_01(){ // Criado a função Texto_01
    return(
        <h1>
            {valor} /* Retorna a variável valor
        </h1>
    );
}
export default Texto_01; // Exportado a função Texto_01