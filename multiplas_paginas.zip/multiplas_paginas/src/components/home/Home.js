import React from "react";
import './Home.css';
function Home() {
    return (
    <div>
        <h3>🎉Bem-vindo ao programa de Conversões🎉</h3>
        <p>Escolha a Conversão desejada</p>
    </div>
);
}
export default Home;