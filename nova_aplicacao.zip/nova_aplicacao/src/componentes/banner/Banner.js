import './Banner.css'; // Importado o documento Banner.css
function Banner(){
    return (
        //JSX
        <body className='banner'> 
            <img src="/imagens/TV.jpg" alt="imagem dev" />
        </body>
    )
}
export default Banner