import './Texto.css';
function Texto(){
    return(
        <header >
            <h1>TV SAMSUNG 55'</h1>
            <p>R$2.500</p>
        </header>
    )
}
export default Texto 