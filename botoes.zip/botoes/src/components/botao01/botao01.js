const Botao_01 = () =>{
    function click(){
        alert("ETEC")
    };
    return(
        <button onClick={click}>
            Botão 1
        </button>
    );
}

export default Botao_01;